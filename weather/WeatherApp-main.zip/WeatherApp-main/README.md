# WeatherApp
This is a simple weather app using react-native.





After downloading zip file, first install node modules with the following command:-
npm install



To run project the command is:-
npm start
